package com.example.my_schedule_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
